// scripts/Halla/Halla/core/config.js

(function (global) {
    "use strict";
    var Halla = (global.Halla = global.Halla || {});

        // --- Herní Konstanty ---
        Halla.GAME_TITLE = "Halla";
        Halla.BASE_MAX_HEALTH = 100;

        // --- Předměty ---
        Halla.ULTIMATE_ITEMS = ["Šasi", "Zdroj", "Chladič", "Optika", "Deska"];
        Halla.ITEM_DISPLAY_NAMES = {
            "Šasi": "Šasi", "Zdroj": "Zdroj", "Chladič": "Chladič", "Optika": "Optika", "Deska": "Deska",
            "mince": "Mince", "Propiska": "Propiska", "Láhev rumu": "Láhev rumu", "Kočka": "Kočka",
            "ID karta": "ID karta", "Kámen": "Kámen", "Krabička cigaret": "Krabička cigaret",
            "Zapalovač": "Zapalovač", "Krabice": "Krabice", "Diplom": "Diplom", "Mega kafe": "Mega kafe"
        };
        Halla.FIXED_ITEMS = ["Propiska"];
        Halla.COIN_ITEM = "mince";
        Halla.COIN_SPAWN_ROOMS = ["placek", "parkoviste", "parkoviste_ovr", "kurarna", "denni_mistnost"];

        // --- Speciální Místnosti ---
        Halla.IVCA_ROOMS = ["zasedacka_ovr", "kuchynka_ovr", "kancl_sachta"];
        Halla.SLOT_SYMBOLS = ["🍋", "🍊", "⭐", "🔔", "🍑", "🍒", "💎"];

        // --- Mapa a UI ---
        Halla.MAP_ORIGIN_X = 0;
        Halla.MAP_ORIGIN_Y = 0;
        Halla.MAP_TEXT_HEIGHT = 1.0;
        Halla.PLAYER_TEXT_HEIGHT = 1.0;
        Halla.HEART_FONT_SIZE = 3.0;
        Halla.FONT_NAME = "Consolas"; // Nová konstanta pro font
        Halla.LAYER_PREFIX = "Halla_"; // Ponecháme pro případné budoucí použití
        Halla.LAYER_PLAYER = "Halla_Player";
        Halla.LAYER_BG = "Halla_BG";
        Halla.LAYER_BOSS = "Halla_Boss";
        Halla.LAYER_HEARTS = "HUD_SRDICKA"; // Přejmenováno z LAYER_UI a opraven název
        Halla.ANIMATION_FRAMES = 10;
        // --- Nové konstanty pro unikátní NPC ---
        Halla.LAYER_UNIQUE_NPC = "Halla_Unique_NPC";
        Halla.UNIQUE_NPCS = {
            "honza":    { name: "Honza",    char: "H", line: "Honza se na tebe jen unaveně podívá a řekne: 'Zase pondělí, co?'" },
            "david":    { name: "David",    char: "D", line: "David kolem tebe projde a zamumlá si pro sebe: 'Tohle musí být hotový do pátku...'" },
            "martin":   { name: "Martin",   char: "M", line: "Martin se opírá o zeď a povzdechne si: 'Ještě že mám ten home office.'" },
            "misa":     { name: "Míša",     char: "Š", line: "Míša se na tebe usměje a prohodí: 'Hlavně se z toho nezbláznit.'" },
            "kristyna": { name: "Kristýna", char: "K", line: "Kristýna si upraví brýle a řekne: 'Už jsi vyplnil docházku?'" },
            "capino":   { name: "Čapíno",   char: "Č", line: "Čapíno se zjeví a zase zmizí. Zanechá za sebou jen vůni svařáku." }
        };


        // --- Balancování Hry ---
        Halla.BALANCE = {
            // Boss
            bossMinSpawnDistance: 3,
            bossRageItemCount: 3,
            bossJindraHeroItemCount: 4,
            bossSkipBase: 0.25,
            bossDemotivatedBonus: 0.3,
            bossCatSkipBonus: 0.1,
            bossCatPanicChance: 0.15,
            bossRageExtraMoveChance: 0.33,
            // Eventy
            auditChance: 0.05, // Sníženo z 0.1
            auditDmgMin: 10,   // Zvýšeno z 5
            auditDmgMax: 25,   // Zvýšeno z 15
            kocmanChance: 0.08,
            kocmanHealMin: 10,
            kocmanHealMax: 20,
            zkratChance: 0.06, // Sníženo z 0.12
            zkratDmgMin: 12,   // Zvýšeno z 8
            zkratDmgMax: 30,   // Zvýšeno z 18
            zkratPerkChance: 0.5,
            // Roaming
            ivcaMoveChance: 0.4,
            ivcaBuffTurns: 3,
            ivcaBuffDmgMul: 0.5,
            // Místnosti
            roomHealBaseMul: 1.0,
            coffeeBoostHealMul: 1.5,
            kurarnaHealBase: 10,
            kurarnaHealMul: 1.0,
            ovrMindDmgMul: 0.7,
            // Endings
            pepikEndingVisitCount: 2,
            // Automat
            slotSpins: 3,
            slotAnimFrames: 15,
            slotAnimDelay: 50,
            slotResultDelay: 1000,
            // Ambient
            ambientMessageChance: 0.2,
            // Unikátní NPC
            uniqueNpcSpawnChance: 0.15, // Šance na spawn každý tah, pokud žádný není
            uniqueNpcLifetime: 10       // Počet tahů, než NPC zmizí
        };

        // --- Třídy Hráče ---
        Halla.PLAYER_CLASSES = {
            "vyrobni_barbar": {
                label: "Výrobní Barbar",
                desc: "Vydrží víc, ale je trochu nešikovný.",
                maxHealthMul: 1.2,
                envDamageMul: 1.1,
                moreEvents: true,
                bossSpawnDistanceMul: 0.8, // Boss se objeví blíže
                rumResistChance: 0.25      // Šance, že se nespotřebuje rum
            },
            "kancelarska_krysa": {
                label: "Kancelářská Krysa",
                desc: "Lépe slyší bosse a má větší štěstí na heal.",
                maxHealthMul: 0.9,
                healMul: 1.2,
                betterListen: true,
                bossSpawnDistanceMul: 1.5, // Boss se objeví dále
                catSoothingEffect: 0.15    // Extra šance na skip bosse s kočkou
            },
            "systemovy_inzenyr": {
                label: "Systémový Inženýr",
                desc: "Boss ho častěji ignoruje.",
                maxHealthMul: 1.0,
                bossSkipMul: 1.25,
                bossSpawnDistanceMul: 1.0, // Standardní vzdálenost
                zkratResistChance: 0.75    // Šance na odvrácení poškození ze zkratu
            }
        };

        // --- Popisy perků pro deník ---
        Halla.PERK_DESCRIPTIONS = {
            "secondChance": "Jednorázová záchrana před bossem.",
            "OVRmind": "Snížený damage z prostředí.",
            "coffeeBoost": "Zvýšený heal z místností.",
            "cableWizard": "Ochrana před příštím zkratem."
        };

        // --- Ambientní hlášky ---
        Halla.AMBIENT_MESSAGES = [
            "Zaslechl jsi vzdálené 'vle, vle, hmm...'",
            "Někde spadla krabice. Nebo člověk.",
            "Projel kolem tebe ještěr s prázdnýma paletama.",
            "Z vedlejší místnosti se ozývá tichý pláč.",
            "Cítíš vůni spálené elektroniky a beznaděje.",
            "Vzpomněl sis na vtip, ale pak sis uvědomil, kde jsi, a zase tě to přešlo."
        ];

})(this);