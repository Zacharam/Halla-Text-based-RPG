// scripts/Halla/Halla/core/state.js
// Stav hry + reset.
// Tahle část je "svatá": drží gameState a spouští init věci z ostatních modulů.

(function () {
    // Bezpečná reference na globální jmenný prostor
    var Halla = this.Halla || (this.Halla = {});

    // Konstanty pro lepší čitelnost a údržbu
    var JINDRA_SPAWN_ROOMS = ["kancl", "houston"];


    // --------------------------------------
    //   STAV HRY + RUNTIME PROMĚNNÉ
    // --------------------------------------

    /**
     * Zkontroluje, zda hra již běží.
     * @returns {boolean} True, pokud existuje platný gameState.
     */
    Halla.isGameInProgress = function() {
        return Halla.gameState && Halla.gameState.running;
    };

    Halla.gameState = null;

    // runtime registry for world phases
    Halla.WORLD_PHASES = new Object(); // Použijeme new Object() pro bezpečnější inicializaci

    // --------------------------------------
    //   POMOCNÉ FUNKCE
    // --------------------------------------

    /**
     * Vrátí objekt s vlastnostmi hráčovy třídy.
     * @returns {object} Objekt třídy nebo null.
     */
    Halla.getPlayerClass = function() {
        if (!Halla.gameState || !Halla.gameState.playerClassId) return null;
        return Halla.PLAYER_CLASSES[Halla.gameState.playerClassId] || null;
    };

    // --------------------------------------
    //   UI: VOLBA POVOLÁNÍ (QCAD-safe)
    //   (NEPOUŽÍVÁ Qt.UserRole / setData)
    // --------------------------------------

Halla.choosePlayerClass = function () {
        var parent = RMainWindowQt.getMainWindow();

        var dlg = new QDialog(parent);
    dlg.setFixedSize(720, 480); // Zamkneme velikost okna

        if (typeof dlg.setWindowTitle === "function") {
            dlg.setWindowTitle(Halla.GAME_TITLE + " – Volba povolání");
        }

        var layout = new QVBoxLayout(dlg);

    // Hlavní titulek
        var lbl = new QLabel(dlg);
        var title = "Jak dneska nastupuješ do Hally?";
        if (typeof lbl.setText === "function") lbl.setText(title);
        else lbl.text = title;
        try {
            if (typeof lbl.setWordWrap === "function") lbl.setWordWrap(true);
            else lbl.wordWrap = true;
        } catch (e) {}
        layout.addWidget(lbl, 0, 0);

    // Horizontální layout pro sloupce s postavami
    var columnsLayout = new QHBoxLayout();
        var chosenId = null;

        for (var id in Halla.PLAYER_CLASSES) {
            if (!Halla.PLAYER_CLASSES.hasOwnProperty(id)) continue;
            var cls = Halla.PLAYER_CLASSES[id];

        // Vertikální layout pro jeden sloupec (obrázek, popis, tlačítko)
        var column = new QVBoxLayout();

        // 1. Obrázek
        var imgLabel = new QLabel(dlg);
        // Použijeme relativní cestu, protože absolutní je nyní uložena pro pozdější použití
        var imagePath = "scripts/Halla/Halla/data/" + id + ".jpg";
        imagePath = imagePath.replace(/\\/g, "/"); 

        var pixmap = new QPixmap(imagePath);
        if (!pixmap.isNull()) {
            // Zmenšíme obrázek na šířku 200px se zachováním poměru stran
            imgLabel.setPixmap(pixmap.scaledToWidth(300, 1)); // Qt.KeepAspectRatio = 1
        }
        // Oprava: Defenzivní nastavení zarovnání pro maximální kompatibilitu
        if (typeof imgLabel.setAlignment === 'function') {
            imgLabel.setAlignment(RS.AlignHCenter);
        } else {
            imgLabel.alignment = RS.AlignHCenter; // Fallback pro starší verze
        }
        column.addWidget(imgLabel, 0, 0);

        // 2. Popis
        var nameLabel = new QLabel("<b>" + (cls.label || id) + "</b>", dlg);
        if (typeof nameLabel.setAlignment === 'function') {
            nameLabel.setAlignment(RS.AlignHCenter);
        } else {
            nameLabel.alignment = RS.AlignHCenter;
        }
        column.addWidget(nameLabel, 0, 0);

        var descLabel = new QLabel(cls.desc || "Žádný popis.", dlg);
        // Oprava: Defenzivní nastavení zalamování textu
        try {
            if (typeof descLabel.setWordWrap === 'function') {
                descLabel.setWordWrap(true);
            } else {
                descLabel.wordWrap = true; // Fallback pro starší verze
            }
        } catch (e) {}
        if (typeof descLabel.setAlignment === 'function') {
            descLabel.setAlignment(RS.AlignHCenter);
        } else {
            descLabel.alignment = RS.AlignHCenter;
        }
        column.addWidget(descLabel, 1, 0); // Stretch factor 1, aby se roztáhl

        // 3. Tlačítko pro výběr
        var btnSelect = new QPushButton("Vybrat", dlg);
        (function(selectedId) { // Uzávěr pro zachování správného 'id'
            if (btnSelect.clicked) {
                btnSelect.clicked.connect(function() {
                    chosenId = selectedId;
                    dlg.accept();
                });
            }
        })(id);
        column.addWidget(btnSelect, 0, 0);

        // Přidáme sloupec do hlavního horizontálního layoutu
        columnsLayout.addLayout(column);
        }

    layout.addLayout(columnsLayout);

    // Přidáme tlačítko Zrušit pro případ, že si hráč nevybere
    var btnCancel = new QPushButton("Zrušit", dlg);
    if (btnCancel.clicked) {
        btnCancel.clicked.connect(function() {
            chosenId = null; // Zajistíme, že se nic nevybere
            dlg.reject();
        });
    }
    layout.addWidget(btnCancel, 0, 0);

        dlg.exec();

    // Pokud hráč dialog zavřel křížkem, vrátíme výchozí třídu
        return chosenId || "vyrobni_barbar";
    };

    // --------------------------------------
    //   RESET HRY
    // --------------------------------------

    Halla.resetGame = function () {

        // Inicializace gameState
        var gs = new Object();
        gs.currentRoom = "placek";
        gs.inventory = new Array();
        gs.running = true;
        gs.visitedRooms = new Array("placek");
        gs.coinRoom = null;
        gs.revealedRooms = new Object();
        gs.hasJindra = false;
        gs.jindraRoom = null;
        gs.kamenikUsed = false;
        gs.hasIvca = false;
        gs.ivcaRoom = null;
        gs.ivcaBuffTurns = 0;
        gs.mapBackgroundEntityId = -1;
        gs.mapPlayerEntityId = -1;
        gs.mapBossEntityId = -1;
        gs.health = Halla.BASE_MAX_HEALTH;
        gs.maxHealth = Halla.BASE_MAX_HEALTH;
        gs.isTurnInProgress = false;
        gs.isFirstTurn = true; // Nový příznak pro první kolo
        gs.staticItemsTaken = new Object(); // Sledování sebraných statických itemů

        gs.boss = new Object();
        gs.boss.active = false;
        gs.boss.room = null;
        gs.boss.turnCounter = 0;
        gs.boss.rage = false;
        gs.boss.demotivatedTurns = 0;
        gs.boss.encounters = 0;

        gs.endings = new Object();
        gs.endings.pepikVisitCount = 0;
        gs.endings.escapedWithCatAndCigs = false;
        gs.endings.rumEnding = false;
        gs.endings.pepikEnding = false;
        gs.endings.jindraHeroEnding = false;

        gs.stats = new Object();
        gs.stats.turns = 0; gs.stats.moves = 0; gs.stats.waits = 0; gs.stats.listens = 0; gs.stats.itemsPicked = 0;
        gs.stats.kurarnaHeals = 0;
        gs.stats.usedKurarnaHeal = false;

        gs.playerClassId = null;
        gs.journal = new Object();
        gs.journal.rooms = new Object(); gs.journal.npcs = new Object(); gs.journal.perks = new Object();

        gs.playerPerks = new Object();
        gs.activeQuests = new Object();

        Halla.gameState = gs;

        // --- výběr classy (UI) ---
        var classId = (typeof Halla.choosePlayerClass === "function")
            ? Halla.choosePlayerClass()
            : "vyrobni_barbar";

        Halla.gameState.playerClassId = classId;

        // přepočet max health dle classy
        var cls = Halla.getPlayerClass();
        if (cls) {
            Halla.gameState.maxHealth = Math.floor(Halla.BASE_MAX_HEALTH * (cls.maxHealthMul || 1.0));
        }
        Halla.gameState.health = Halla.gameState.maxHealth;

        // init random events / quests (pokud už existují)
        if (typeof Halla.initRandomEvents === "function") {
            Halla.initRandomEvents();
        }
        if (typeof Halla.initQuests === "function") {
            Halla.initQuests();
        }
        // Init unikátních NPC
        if (typeof Halla.initUniqueNpcs === "function") {
            Halla.initUniqueNpcs();
        }

        // Ivča buff
        Halla.gameState.ivcaBuffTurns = 0;

        // náhodné rozmístění ultimate itemů
        if (typeof Halla.shuffleUltimateItems === "function") {
            Halla.shuffleUltimateItems();
        }

        // Jindra start pozice
        Halla.gameState.jindraRoom = Halla.randomFromArray(JINDRA_SPAWN_ROOMS);
        Halla.gameState.hasJindra = false;
        Halla.gameState.kamenikUsed = false;

        // --- MINCE: náhodné umístění do gameState ---
        Halla.gameState.coinRoom = Halla.randomFromArray(Halla.COIN_SPAWN_ROOMS);

        // --- PROPSIKA (quest item): náhodné umístění ---
        var propiskaRooms = new Array("kancl", "kancl_sachta", "chodba_ovr");
        var propiskaRoom = Halla.randomFromArray(propiskaRooms);
        if (propiskaRoom) {
            // Použijeme bezpečnější metody pro inicializaci
            if (!Halla.gameState.itemLocations) {
                Halla.gameState.itemLocations = new Object();
            }
            if (!Halla.gameState.itemLocations[propiskaRoom]) {
                Halla.gameState.itemLocations[propiskaRoom] = new Array();
            }
            Halla.gameState.itemLocations[propiskaRoom].push("Propiska");
        }

        // world phases registry
        if (typeof Halla.initWorldPhases === "function") {
            Halla.initWorldPhases();
        }
    };

})();
