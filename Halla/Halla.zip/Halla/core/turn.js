// scripts/Halla/Halla/core/turn.js
// Hlavní tah hry + gameLoop.
// Orchestrace: UI -> akce -> advanceWorldOneTurn -> render.
(function () {
    "use strict";
    // Bezpečná reference na globální jmenný prostor
    var Halla = this.Halla || (this.Halla = {});

    // --------------------------------------
    //   COMMAND HANDLERS (Data-driven design)
    // --------------------------------------

    /**
     * Pomocná funkce pro vstup do tajné místnosti.
     * @returns {boolean} True, pokud byl vstup úspěšný.
     */
    function _enterSecretRoom() {
        var gs = Halla.gameState;
        if (gs.currentRoom === "chodba_ovr" &&
            Halla.hasItemInInventory("Kočka") &&
            Halla.hasItemInInventory("Diplom")) {

            var nextRoomId = "tajna_mistnost";
            gs.currentRoom = nextRoomId;
            if (gs.visitedRooms.indexOf(nextRoomId) === -1) {
                gs.visitedRooms.push(nextRoomId);
            }
            return true;
        }
        Halla.showWarning("Zatím nevíš, jak tudy projít.\nMožná potřebuješ víc koček nebo papírů.");
        return false;
    }

    /**
     * Pomocná funkce pro sebrání předmětu z místnosti.
     * @param {string} itemName - Název předmětu k sebrání.
     * @returns {boolean} True, pokud byl předmět úspěšně sebrán.
     */
    function _takeItem(itemName) {
        var gs = Halla.gameState;
        var room = Halla.rooms[gs.currentRoom];
        var targetNorm = Halla.normalizeString(itemName);

        // 1. Mince
        if (gs.coinRoom === gs.currentRoom && targetNorm === Halla.normalizeString(Halla.COIN_ITEM)) {
            Halla.giveItemToInventory(Halla.COIN_ITEM);
            gs.coinRoom = null;
            return true;
        }

        // 2. Dynamické itemy (ultimate, quest)
        var dynamicItems = gs.itemLocations && gs.itemLocations[gs.currentRoom];
        if (dynamicItems) {
            for (var i = dynamicItems.length - 1; i >= 0; i--) {
                if (Halla.normalizeString(dynamicItems[i]) === targetNorm) {
                    var item = dynamicItems.splice(i, 1)[0];
                    Halla.giveItemToInventory(item);
                    return true;
                }
            }
        }

        // 3. Statické itemy
        if (room.items) {
            for (var j = 0; j < room.items.length; j++) {
                var staticItem = room.items[j];
                var itemKey = gs.currentRoom + "_" + Halla.normalizeString(staticItem);
                if (Halla.normalizeString(staticItem) === targetNorm && (!gs.staticItemsTaken || !gs.staticItemsTaken[itemKey])) {
                    Halla.giveItemToInventory(staticItem);
                    if (!gs.staticItemsTaken) gs.staticItemsTaken = new Object();
                    gs.staticItemsTaken[itemKey] = true;
                    return true;
                }
            }
        }

        return false;
    }

    var COMMANDS = {
        "konec": function(target) {
            Halla.gameState.running = false;
            return { advanceTurn: false };
        },
        "denik": function(target) {
            return Halla.runUiAction(function() {
                if (typeof Halla.showJournalDialog === "function") Halla.showJournalDialog();
                else Halla.showInfo("Deník není k dispozici. (chybí journal.js)");
            });
        },
        "jdi": function(target) {
            var gs = Halla.gameState;
            var room = Halla.rooms[gs.currentRoom];
            var normDir = Halla.normalizeString(target);

            if (normDir === "tajne") { // Z historických důvodů
                return { advanceTurn: _enterSecretRoom(), actionType: "move" };
            }

            if (room.exits && room.exits[normDir]) {
                var nextRoomId = room.exits[normDir];
                gs.currentRoom = nextRoomId;
                if (gs.visitedRooms.indexOf(nextRoomId) === -1) gs.visitedRooms.push(nextRoomId);

                // Kameníkův zásek
                if (nextRoomId === "dilna_vyroba" && gs.hasJindra && !gs.kamenikUsed) {
                    gs.kamenikUsed = true;
                    Halla.showInfo("S Jindrou vkročíte do dílny výroby...\nZdrží vás to na dvě kola...");
                    for (var kk = 0; kk < 2 && gs.running; kk++) {
                        Halla.advanceWorldOneTurn("wait");
                    }
                    return { advanceTurn: false }; // Svět už pokročil
                }
                return { advanceTurn: true, actionType: "move" };
            }

            Halla.showWarning("Tudy cesta nevede.");
            return { advanceTurn: false };
        },
        "tajny": function(target) { // Pro volbu ze seznamu
            return { advanceTurn: _enterSecretRoom(), actionType: "move" };
        },
        "vezmi": function(target) {
            if (_takeItem(target)) {
                Halla.gameState.stats.itemsPicked = (Halla.gameState.stats.itemsPicked || 0) + 1;
                Halla.showInfo("Vzal jsi: " + target);
                if (target === "Diplom" && !Halla.hasPerk("OVRmind")) {
                    Halla.showInfo("Diplom ti otevírá dveře k vyššímu utrpení...");
                }
            } else {
                Halla.showWarning("Tenhle předmět tu není.");
            }
            return { advanceTurn: false }; // Sebrání itemu neposouvá tah
        },
        "cekej": function(target) {
            Halla.showInfo("Rozhodl ses jen stát a existovat.\nSvět se mezitím hýbe dál.");
            return { advanceTurn: true, actionType: "wait" };
        },
        "naslouchej": function(target) {
            var gs = Halla.gameState;
            var msg;
            if (!gs.boss.active || !gs.boss.room) {
                msg = "Zaposloucháš se… ale slyšíš jen vrnění ventilátorů a tiché zoufalství.";
            } else {
                var dist = Halla.estimateDistanceToBoss(gs.currentRoom, gs.boss.room);
                if (dist < 0) msg = "Boss je někde v labyrintu, ale nemáš ponětí kde.";
                else if (dist === 0) msg = "Je přímo s tebou. Pokud tohle čteš, máš problém.";
                else if (dist <= 2) msg = "Cítíš jeho přítomnost.\nBoss je hodně blízko.";
                else if (dist <= 4) msg = "Někde poblíž v hale něco tiše číhá.\nBoss je ve střední vzdálenosti.";
                else msg = "Zvuky jsou tlumené.\nBoss je dost daleko… zatím.";

                var cls = Halla.getPlayerClass ? Halla.getPlayerClass() : null;
                if (cls && cls.betterListen) {
                    msg += "\n\n(Jako kancelářský mág odhaduješ vzdálenost na " + dist + " kroků.)";
                }
            }
            Halla.showInfo("Zaposloucháš se do šumu Hally.\n\n" + msg);
            return { advanceTurn: true, actionType: "listen" };
        },
        "rozhlidni": function(target) {
            return Halla.runUiAction(function() { _handleLookAround(); });
        }
    };

    // --------------------------------------
    //   HLAVNÍ TAH
    // --------------------------------------

    Halla.performGameTurn = function (callbacks) {
        var gs = Halla.gameState;
        if (!gs) return;

        if (gs.isTurnInProgress) return;

        if (!gs.running) {
            Halla.showInfo("Hra byla ukončena.");
            return;
        }

        gs.isTurnInProgress = true;

        // --- AutoZoom při prvním kole ---
        // Toto je nejspolehlivější místo, protože se provede až poté,
        // co byly všechny úvodní kreslící operace zařazeny do fronty.
        if (gs.isFirstTurn) {
            if (typeof Halla.zoomToMap === "function") {
                Halla.zoomToMap();
            }
            gs.isFirstTurn = false;
        }

        var room = Halla.rooms[gs.currentRoom];
        if (!room) {
            gs.running = false;
            gs.isTurnInProgress = false;
            return;
        }

        // POZOR: `gs.revealedRooms = {}` je v QtScript nebezpečné.
        if (!gs.revealedRooms) {
            gs.revealedRooms = new Object();
        }
        var roomRevealed = !!gs.revealedRooms[gs.currentRoom];

        // --- triggers při vstupu (questy/NPC/perky/počítadla) ---
        if (typeof Halla.handleRoomEntryEvents === "function") {
            Halla.handleRoomEntryEvents();
            if (!gs.running) {
                gs.isTurnInProgress = false;
                return;
            }
        }

        // --- setkání s unikátním NPC ---
        if (typeof Halla.handleUniqueNpcEncounter === "function") {
            Halla.handleUniqueNpcEncounter();
        }

        // --- endingy, co se mohou stát hned po vstupu ---
        if (typeof Halla.checkSpecialEndings === "function") {
            Halla.checkSpecialEndings();
            if (!gs.running) {
                gs.isTurnInProgress = false;
                return;
            }
        }

        // --- render mapy ---
        if (typeof Halla.drawAsciiMapToCanvas === "function") {
            var mapLines = Halla.generateAsciiMap();
            if (mapLines) {
                Halla.drawAsciiMapToCanvas(mapLines);
            }
        }

        // --- popis ---
        var desc = "";
        desc += "========================================\n";
        desc += "Lokace: " + gs.currentRoom + "\n\n";
        desc += room.description;

        if (typeof Halla.getAmbientMessageOrEmpty === "function") {
            desc += Halla.getAmbientMessageOrEmpty();
        }

        desc += "\n\nHP: " + gs.health + "/" + gs.maxHealth + "\n";

        // Zobrazení všech itemů v místnosti (statické + dynamické)
        if (roomRevealed) {
            var allItemsInRoom = new Array();
            if (room.items && room.items.length > 0) {
                allItemsInRoom = allItemsInRoom.concat(room.items);
            }
            if (gs.itemLocations && gs.itemLocations[gs.currentRoom]) {
                allItemsInRoom = allItemsInRoom.concat(gs.itemLocations[gs.currentRoom]);
            }
            if (gs.coinRoom === gs.currentRoom) {
                allItemsInRoom.push(Halla.COIN_ITEM);
            }

            if (allItemsInRoom.length > 0) {
                desc += "\nVidíš zde: " + allItemsInRoom.join(", ");
            }
        }

        if (gs.inventory && gs.inventory.length > 0) {
            var displayInv = new Array();
            for (var i = 0; i < gs.inventory.length; i++) {
                displayInv.push(Halla.ITEM_DISPLAY_NAMES[gs.inventory[i]] || gs.inventory[i]);
            }
            desc += "\n\nV inventáři máš: " + displayInv.join(", ");
        }

        // --- choices ---
        var choices = [];

        // secret volba
        if (gs.currentRoom === "chodba_ovr" &&
            Halla.hasItemInInventory("Kočka") &&
            Halla.hasItemInInventory("Diplom")) {
            choices.push("tajny vstup");
        }

        // pickup volby jen pokud je room revealed
        if (roomRevealed) {
            var allItemsForPickup = new Array();
            if (room.items && room.items.length > 0) {
                // Přidáme jen itemy, které ještě nebyly sebrány
                for (var si = 0; si < room.items.length; si++) {
                    var staticItem = room.items[si];
                    var itemKey = gs.currentRoom + "_" + Halla.normalizeString(staticItem);
                    if (!gs.staticItemsTaken || !gs.staticItemsTaken[itemKey]) {
                        allItemsForPickup.push(staticItem);
                    }
                }
            }
            if (gs.itemLocations && gs.itemLocations[gs.currentRoom]) {
                allItemsForPickup = allItemsForPickup.concat(gs.itemLocations[gs.currentRoom]);
            }
            if (gs.coinRoom === gs.currentRoom) {
                allItemsForPickup.push(Halla.COIN_ITEM);
            }

            if (allItemsForPickup.length > 0) {
                for (var i = 0; i < allItemsForPickup.length; i++) {
                    // Odstraníme duplicity, pokud by se náhodou vyskytly
                    if (choices.indexOf("vezmi " + allItemsForPickup[i]) === -1) {
                        choices.push("vezmi " + allItemsForPickup[i]);
                    }
                }
            }
        }

        choices.push("rozhlidni se");
        choices.push("cekej");
        choices.push("naslouchej bossovi");
        choices.push("denik");
        choices.push("konec");

        // --- dialog ---
        var command = Halla.getGameCommandDialog(desc, choices, room);

        var advanceTurn = true;

        if (!command) {
            gs.running = false;
            advanceTurn = false;
        } else {
            var parts = String(command).split(" ");
            var action = parts[0];
            var target = parts.slice(1).join(" ");

            var handler = COMMANDS[action];
            if (typeof handler === "function") {
                var result = handler(target);
                advanceTurn = result.advanceTurn;
                if (gs.running && advanceTurn) {
                    Halla.advanceWorldOneTurn(result.actionType);
                }
            } else {
                advanceTurn = false;
            }
        }
        gs.isTurnInProgress = false;

        var actionType = (result && result.actionType) ? result.actionType : null;

        // Zavoláme onTurnEnd callback, pokud existuje (pro pohyb roaming NPC atd.)
        if (callbacks && typeof callbacks.onTurnEnd === 'function') {
            callbacks.onTurnEnd(actionType);
        }
    };

    // --------------------------------------
    //   GAME LOOP – NEREKURZIVNÍ
    // --------------------------------------

    Halla.gameLoop = function (callbacks) {
        if (!Halla.gameState) {
            Halla.resetGame();
        }

        if (typeof Halla.updateHealthHearts === "function") {
            Halla.updateHealthHearts();
        }

        while (Halla.gameState && Halla.gameState.running) {
            // Zavoláme onTurnStart callback, pokud existuje
            if (callbacks && typeof callbacks.onTurnStart === 'function') {
                callbacks.onTurnStart();
            }
            if (!Halla.gameState.running) break; // onTurnStart mohl ukončit hru
            Halla.performGameTurn(callbacks);
        }
    };

    /**
     * Zpracovává logiku pro akci "rozhlidni se".
     * @private
     */
    function _handleLookAround() {
        var gs = Halla.gameState;
        gs.revealedRooms[gs.currentRoom] = true;

        // Speciální případ: automat v chodbě
        if (gs.currentRoom === "chodba_ovr") {
            if (Halla.hasItemInInventory(Halla.COIN_ITEM)) {
                Halla.showInfo("Rozhlédneš se... V rohu stojí výherní automat a opírá se o něj Vojta.");
                var yes = Halla.askYesNo(Halla.GAME_TITLE + " – Automat", "Chceš hodit Minci do automatu?", "Ano", "Ne");
                if (yes) {
                    if (typeof Halla.playSlotMachine === "function") Halla.playSlotMachine();
                    else Halla.showInfo("Automat nefunguje. (chybí slotMachine.js)");
                }
            } else {
                Halla.showInfo("Rozhlédneš se po chodbě OVR. Automat tam stojí, ale bez Mince je ti k ničemu.");
            }
            return; // Konec specifické logiky
        }

        // Obecné rozhlédnutí
        var extra = Halla.getAmbientMessageOrEmpty ? Halla.getAmbientMessageOrEmpty() : "";
        if (extra === "") {
            extra = "\n\nNic zvláštního nevidíš. Jen další den v práci.";
        }

        var allItemsInRoom = [];
        var roomItems = Halla.rooms[gs.currentRoom].items;
        if (roomItems && roomItems.length > 0) {
            for (var i = 0; i < roomItems.length; i++) {
                var staticItem = roomItems[i];
                var itemKey = gs.currentRoom + "_" + Halla.normalizeString(staticItem);
                if (!gs.staticItemsTaken || !gs.staticItemsTaken[itemKey]) {
                    allItemsInRoom.push(staticItem);
                }
            }
        }

        var dynamicItems = gs.itemLocations && gs.itemLocations[gs.currentRoom];
        if (dynamicItems) {
            allItemsInRoom = allItemsInRoom.concat(dynamicItems);
        }

        if (gs.coinRoom === gs.currentRoom) {
            allItemsInRoom.push(Halla.COIN_ITEM);
        }

        if (allItemsInRoom.length > 0) {
            extra += "\n\nPo chvíli pátrání si všimneš:\n- " + allItemsInRoom.join("\n- ");
        }

        Halla.showInfo("Rozhlédneš se kolem sebe." + extra);
    }


})();
