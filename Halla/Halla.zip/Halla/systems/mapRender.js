// temporary fixed mapRender
(function (global) {
    "use strict";
    global.Halla = global.Halla || {};
    var Halla = global.Halla;

    var mapString = // Fallback map
        "░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░┌────────────────────────┐░░░░░░┌──────┐░░░\n" +
        "░░░░░░░░░░░░░░░░┌───────┐░░░░░░░░░│                        ├══════┤      │░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░\n" +
        "░░░░┌═══════════┤       ├═════════┤                        │      └──────┘░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░\n" +
        "░░░░║░░░░░░░░░░░└───────┘░░░░░░░░░└────────────────┬───────┘░░░░░░░░░░░░░░░░░\n" +
        "░░░░║░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░ ║ ░░░░░░░░░░  [NEON VOID]\n" +
        "░░░░║░░░░                 ░░░░░░░░░░░░░░░░░░░░░░░░ ║ ░░░░░░░░░░\n" +
        "░░░░║░░░░                 ░░░┌───────┐░░░░░┌───────┴───────┐░░░  DATA BLOCK B7\n" +
        "░░░░║░░░░                 ░░░│       │░░░░░│               │░░░\n" +
        "░░░░║░░░░                 ░░░└───┬───┘░░░░░└───────┬───────┘░░░\n" +
        "░░░░║░░░░                 ░░░░░░ ║ ░░░░░░░░░░░░░░░ ║ ░░░░░░░░░░░░░░░░░░░░░░░░░░░ NET-TUNNEL\n" +
        "░░░░║░░░░       ░░░░░░░░░░░░░░░░ ║ ░░░░░░░░░░░░░░░ ║ ░░░┌────────────────────┐░░\n" +
        "░░┌─┴┐░░░       ░░┌──────────────┴─┐░░░░░░░░░┌─────┴─┐░░│                    │░░  GRID SECTOR 69\n" +
        "░░│  │░░░       ░░│                ├═════════┤       ├══│                    │░░   ░┌──────┐░░░░░░░░░░░░░░░░\n" +
        "░░│  │░░░       ░░└───┬────────────┘         └───────┘  │                    ├══════┤      │░░░░░░░░░░░░░░░░\n" +
        "░░│  │░░░       ░░░░░ ║ ░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░│                    │░░   ░└──────┘░░░░░░░░░░░░░░░░\n" +
        "░░│  │░░░░░░░░░░░░░░░ ║ ░░░░░░░┌──────────┐░░░░░░░░░░░░░│                    │░░  [SUBNET CAVES]\n" +
        "░░│  │░░░┌─────┐░░░┌──┴────┐░░░│          │       ░░░░░░└──┬─────────────────┘░░\n" +
        "░░│  ├═══┤     ├═══┤       ├═══┤          ├═════┐ ░░░░░░░░ ║ ░░░░░░░░░░░░░░░░░░░  ACCESS PORT 05\n" +
        "░░│  │░░░└─────┘░░░└──┬────┘░░░│          │     ║ ░░░░░░░░ ║ ░░░░░░░░░░░░░░░░░░░\n" +
        "░░│  │░░░░░░░░░░░░░░░ ║ ░░░░░░░└──────┬───┘     ║   ┌──────┴──────────────────┐░  DEFENSE GRID\n" +
        "░░│  │░░░        ░░░┌─┴─┐░░░░░░░░░░░░ │ ░░░░░   ║ ░░│                         │░\n" +
        "░░│  │░░░        ░░░│   │░░░    ░░░░░ │ ░░░░░   ║ ░░│                         │░░   ░┌──────┐░░░░░░░░░░░░░░░░\n" +
        "░░│  │░░░        ░░░│   │░░░    ░░┌───┴───┐░░   └═══┤                         ├══════┤      │░░░░░░░░░░░░░░░░\n" +
        "░░│  │░░░        ░░░│   │░░░    ░░│       │░░     ░░│                         │░░   ░└──────┘░░░░░░░░░░░░░░░░\n" +
        "░░│  │░░░        ░░░│   │░░░    ░░│       │░░     ░░│                         │░\n" +
        "░░│  │░░░        ░░░└─┬─┘░░░    ░░└───────┘░░     ░░└───────────┬─────────────┘░───ELEVATOR 121F\n" +
        "░░└──┘░░░        ░░░░ ║ ░░░░    ░░░░░░░░░░░░░     ░░░░░░░░░░░░░ ║ ░░░░░░░░░░░░░░░░░░░░░░───ERROR 04S\n" +
        "░░░░░░░░░        ░░░░ ║ ░░░░░░░░░░░░░░░░░░░░░                   ║ \n" +
        "░░░░░░░░░░░░░░░░░░░┌──┴─┐░░░░░░░░░┌───────┐░░░░░░░░░░░░░░░░░░░░ ║ ░░░░░░░░░░░░░░░░░░░░░░░░░░░ MAINFRAME COIL\n" +
        "░░░░░░░░░┌──┐░░░░░░│    │░░░░░░░░░│       │░░░░░░░░░┌───────────┴────────────┐░░   ░┌──────┐░░░░░░░░░░░\n" +
        "░░░░░░░░░│  ├══════┤    ├═════════┤       ├═════════┤                        ├══════┤      │░░░░░░░░░░░\n" +
        "░░░░░░░░░│  │░░░░░░│    │░░░░░░░░░│       │░░░░░░░░░│                        │░░   ░│      │░░░░░░░░░░░\n" +
        "░░░░░░░░░│  │░░░░░░└────┘░░░░░░░░░└──┬────┘░░░░░░░░░└────────────────────────┘░░   ░└──────┘░░░░░░░░░░░\n" +
        "░░░░░░░░░└──┘░░░░░░░░░░░░░░░░░░░░░░░ ║ ░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░  LOW-SIGNAL ZONE\n" +
        "░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░ ║ ░░░░░░░░┌┐┌┬──┬┐┌┐┌──┐▒▒▒▒▒▒▒▒ [CYBER RELIC]\n" +
        "░░░░░░░░░░░┌─────────────────────────┴────┐░░░░│└┘│┌┐│││││┌┐│▒▒▒▒▒▒▒▒ ACCESS PANEL\n" +
        "░░░░░░░░░░░│                              │░░░░│┌┐│├┤│└┤└┤├┤│▒▒▒▒▒▒▒▒ NODE ARRAY\n" +
        "░░░░░░░░░░░└──────────────────────────────┘░░░░└┘└┴┘└┴─┴─┴┘└┘▒▒▒▒▒▒▒▒ SIGNAL TOMB\n" +
        "░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒\n" +
        "░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░";
    var CUSTOM_MAP_LINES = (Halla && Halla.CUSTOM_MAP_LINES) ? Halla.CUSTOM_MAP_LINES.slice() : mapString.split("\n");

    // In the original script, the background was a sub-layer of the player layer.
    // Let's restore that logic for correct visibility.
    var LAYER_PLAYER = Halla.LAYER_PLAYER || "Halla_Player";
    var LAYER_BG = LAYER_PLAYER + (typeof RLayer !== 'undefined' ? RLayer.getHierarchySeparator() : "|") + "BG";

    // This data is critical for rendering and should be defined directly here
    // to avoid load order issues.
    var ROOM_CHAR_POS = {
        "placek":           { x: 18, y: 2 },
        "parkoviste":       { x: 48, y: 2 },
        "denni_mistnost":   { x: 53, y: 7 },
        "dilna_vyroba":     { x: 28, y: 12 },
        "dilna_mechanicka": { x: 69, y: 13 },
        "houston":          { x: 35, y: 7 },
        "mistrovna":        { x: 51, y: 12 },
        "sklad":            { x: 66, y: 22 },
        "osazovacka":       { x: 91, y: 22 },
        "dilna_ovr":        { x: 40, y: 17 },
        "zasedacka_ovr":    { x: 40, y: 24 },
        "kuchynka_ovr":     { x: 22, y: 30 },
        "chodba_ovr":       { x: 38, y: 30 },
        "kancl_sachta":     { x: 10, y: 30 },
        "kancl":            { x: 25, y: 36 },
        "temna_mistnost":   { x: 66, y: 30 },
        "kancl_tom":        { x: 87, y: 30 },
        "parkoviste_ovr":   { x: 4,  y: 17 },
        "kurarna":          { x: 12, y: 17 },
        "vestibul_ovr":     { x: 22, y: 17 },
        "kobot":            { x: 88, y: 13 },
        "shody_ovr":        { x: 22, y: 23 },
        "pepik":            { x: 70, y: 1 },
        "tajna_mistnost":   { x: 8, y: 25 }
    };

    function getBaseMapLines() {
        // Prefer live Halla.CUSTOM_MAP_LINES if available (may be set after this file is included)
        // Re-check Halla.CUSTOM_MAP_LINES as it might have been populated by an include() call
        // that happened after this file was initially parsed.
        var liveMapLines = (Halla && Halla.CUSTOM_MAP_LINES) ? Halla.CUSTOM_MAP_LINES.slice() : null;
        if (liveMapLines && liveMapLines.length > 0) return liveMapLines;
        if (Halla && Halla.CUSTOM_MAP_LINES && Halla.CUSTOM_MAP_LINES.length > 0) {
            try { return Halla.CUSTOM_MAP_LINES.slice(); } catch (e) { /* ignore */ }
        }
        if (!CUSTOM_MAP_LINES || CUSTOM_MAP_LINES.length === 0) return ["NO MAP DATA"];
        return CUSTOM_MAP_LINES.slice();
    }

    function createLayerIfNotExists(doc, di, layerName, color) {
        if (!doc.hasLayer(layerName)) {
            // Ensure parent layer exists if this is a sub-layer
            var separator = typeof RLayer !== 'undefined' ? RLayer.getHierarchySeparator() : "|";
            if (layerName.indexOf(separator) > -1) {
                var parentName = layerName.substring(0, layerName.lastIndexOf(separator));
                if (parentName && !doc.hasLayer(parentName)) {
                    createLayerIfNotExists(doc, di, parentName);
                }
            }
            var layer = new RLayer(doc, layerName);
            if (color) layer.setColor(color); // Nastavíme barvu, pokud je definována
            var op = new RAddObjectOperation(layer, false);
            di.applyOperation(op);
        }
    }

    function ensureLayerAndGetId(layerName, color) {
        try {
            var di = EAction.getDocumentInterface(); if (!di) return -1;
            var doc = di.getDocument(); if (!doc) return -1;
            
            createLayerIfNotExists(doc, di, layerName, color);

            if (typeof doc.getLayerId === 'function') {
                return doc.getLayerId(layerName);
            }
            if (typeof doc.getLayer === 'function') {
                var layer = doc.getLayer(layerName);
                if (layer && typeof layer.getId === 'function') {
                    return layer.getId();
                }
            }
        } catch (e) {
            // ignore errors, return -1
        }
        return -1;
    }

    function deleteLayerEntities(layerId) {
        if (layerId < 0) return;
        try {
            var di = EAction.getDocumentInterface(); if (!di) return;
            var op = di.deleteObjects(di.getObjectsByLayer(layerId));
            if (op) di.applyOperation(op);
        } catch (e) { /* ignore */ }
    }

    function addSimpleTextToLayerByName(layerName, text, x, y, textHeight, color, isSimple) {
        try {
            var di = EAction.getDocumentInterface(); if (!di) return;
            var doc = di.getDocument(); if (!doc) return;
            var layerId = ensureLayerAndGetId(layerName);

            var td = null;
            // The RTextData constructor can vary between QCAD versions.
            // This defensive approach tries a common constructor, then falls back
            // to a default constructor with individual setters.
            try {
                // Try a common constructor signature first.
                td = new RTextData(text, new RVector(x, y), textHeight, 0);
            } catch (e1) {
                // If that fails, fall back to the default constructor and individual setters.
                try {
                    td = new RTextData();
                    if (typeof td.setText === 'function') td.setText(text);
                    // Some versions use setPosition, others use setInsertionPoint.
                    if (typeof td.setPosition === 'function') {
                        td.setPosition(new RVector(x, y));
                    } else if (typeof td.setInsertionPoint === 'function') {
                        td.setInsertionPoint(new RVector(x, y));
                    }
                    if (typeof td.setHeight === 'function') td.setHeight(textHeight);
                } catch (e2) {
                    // If even this fails, we cannot create the text object.
                    td = null;
                }
            }

            if (!td) { return; } // Cannot proceed if text data object creation failed.

            // Set remaining properties individually for maximum compatibility.
            if (typeof td.setLayerId === 'function' && layerId >= 0) td.setLayerId(layerId);
            else if (typeof td.setLayerName === 'function') td.setLayerName(layerName);
            if (color && typeof td.setColor === 'function') td.setColor(color);
            if (typeof td.setFontName === 'function') td.setFontName(Halla.FONT_NAME);
            if (typeof td.setBold === 'function') td.setBold(false);
            if (typeof td.setItalic === 'function') td.setItalic(false);
            if (typeof td.setSimple === 'function') td.setSimple(isSimple);

            var te = new RTextEntity(doc, td);
            var op = new RAddObjectOperation(te, false);
            di.applyOperation(op);
        } catch (e) {
            // Log error to help with debugging if something still goes wrong.
            if (typeof EAction !== 'undefined' && EAction.handleUserMessage) {
                EAction.handleUserMessage("Halla mapRender Error: " + e);
            }
        }
    }

    function zoomToMap(doc, di) {
        var layerNames = [LAYER_BG, (Halla.LAYER_PLAYER || "Halla_Player"), (Halla.LAYER_BOSS || "Halla_Boss")];
        var bbox = null;
        var anyValid = false;

        try {
            for (var ln = 0; ln < layerNames.length; ln++) {
                var layerId = doc.getLayerId(layerNames[ln]);
                if (layerId === -1) continue;

                var ids = doc.queryLayerEntities(layerId);
                if (isNull(ids) || ids.length === 0) continue;

                for (var i = 0; i < ids.length; i++) {
                    var e = doc.queryEntity(ids[i]);
                    if (!isNull(e)) {
                        var eb = e.getBoundingBox();
                        if (eb.isValid()) {
                            if (!anyValid) {
                                bbox = eb;
                                anyValid = true;
                            } else {
                                bbox.growToInclude(eb);
                            }
                        }
                    }
                }
            }

            if (anyValid && bbox && bbox.isValid()) {
                bbox.grow(5);
                di.zoomTo(bbox);
            }
        } catch (e) {
            // Fallback if bounding box logic fails
            try { di.zoomToAuto(); } catch (e2) { /* ignore */ }
        }
    }

    function generateAsciiMap() {
        var y, x;
        var gs = Halla.gameState;
        if (!gs) return null;

        var baseMap = getBaseMapLines();
        var playerLines = [];

        for (y = 0; y < baseMap.length; y++) {
            playerLines.push(" ".repeat(baseMap[y].length));
        }

        var pos = ROOM_CHAR_POS[gs.currentRoom];
        if (pos) {
            var rowChars = playerLines[pos.y].split("");
            if (pos.x >= 0 && pos.x < rowChars.length) {
                var playerChar = (Halla.ANIMATION_FRAMES && Halla.ANIMATION_FRAMES.player) ? Halla.ANIMATION_FRAMES.player[0] : "P";
                if (Halla.hasItemInInventory("Kočka")) {
                    playerChar = (Halla.ANIMATION_FRAMES && Halla.ANIMATION_FRAMES.player) ? Halla.ANIMATION_FRAMES.player[1] : "C";
                }
                rowChars[pos.x] = playerChar;
            }
            playerLines[pos.y] = rowChars.join("");
        }

        if (gs.visitedRooms && gs.visitedRooms.length > 0) {
            for (var v = 0; v < gs.visitedRooms.length; v++) {
                var roomId = gs.visitedRooms[v];
                if (roomId === gs.currentRoom) continue;
                var p = ROOM_CHAR_POS[roomId];
                if (p && p.y >= 0 && p.y < playerLines.length) {
                    var rowArr2 = playerLines[p.y].split("");
                    if (p.x >= 0 && p.x < rowArr2.length && rowArr2[p.x] === " ") {
                        rowArr2[p.x] = "×";
                        playerLines[p.y] = rowArr2.join("");
                    }
                }
            }
        }

        // Oprava: Přístup k datům bosse přes novou strukturu gameState.boss
        var bossState = gs.boss || {};
        var showBoss = bossState.active && bossState.room && ((bossState.turnCounter % 3 === 0) || Halla.hasItemInInventory("Kočka"));
        var bossPos = null;
        var bossChar = (Halla.ANIMATION_FRAMES && Halla.ANIMATION_FRAMES.boss) ? Halla.ANIMATION_FRAMES.boss[0] : "B";

        if (showBoss) {
            var bp = ROOM_CHAR_POS[bossState.room];
            if (bp) {
                bossPos = { x: bp.x, y: bp.y };
                // Oprava: Přístup k 'rage' stavu přes bossState
                if (bossState.rage && Math.random() < (Halla.BALANCE ? Halla.BALANCE.bossAnimationChance : 0.33)) {
                    bossChar = (Halla.ANIMATION_FRAMES && Halla.ANIMATION_FRAMES.boss) ? Halla.ANIMATION_FRAMES.boss[1] : "B";
                }
            }
        }

        // Unikátní NPC
        var uniqueNpcState = gs.uniqueNpc || {};
        var showUniqueNpc = uniqueNpcState.activeNpcId && uniqueNpcState.room && (uniqueNpcState.turnCounter % 3 === 0);
        var uniqueNpcPos = null;
        var uniqueNpcChar = "?";

        if (showUniqueNpc) {
            var npcId = uniqueNpcState.activeNpcId;
            var npcData = Halla.UNIQUE_NPCS[npcId];
            var npcRoomPos = ROOM_CHAR_POS[uniqueNpcState.room];
            if (npcData && npcRoomPos) {
                uniqueNpcPos = { x: npcRoomPos.x, y: npcRoomPos.y };
                uniqueNpcChar = npcData.char;
            }
        }

        return {
            background: baseMap.join("\n"),
            player: playerLines.join("\n"),
            bossPos: bossPos,
            bossChar: bossChar,
            uniqueNpcPos: uniqueNpcPos,
            uniqueNpcChar: uniqueNpcChar
        };
    }

    function drawAsciiMapToCanvas(mapData) {
        var di = EAction.getDocumentInterface(); if (!di) return;
        var doc = di.getDocument(); if (!doc) return;
        var gs = Halla.gameState; if (!gs) return false;

        var bgLayerId = ensureLayerAndGetId(LAYER_BG, new RColor(150, 150, 150)); // Používáme lokální LAYER_BG
        var playerLayerId = ensureLayerAndGetId(LAYER_PLAYER, new RColor(100, 255, 100)); // Používáme lokální LAYER_PLAYER
        var bossLayerId = ensureLayerAndGetId(Halla.LAYER_BOSS, new RColor(255, 50, 50));
        var uniqueNpcLayerId = ensureLayerAndGetId(Halla.LAYER_UNIQUE_NPC, new RColor(100, 150, 255)); // Modrá barva pro NPC

        if (!mapData) mapData = generateAsciiMap();
        if (!mapData || !mapData.background) return false;

        var delOp = new RDeleteObjectsOperation();
        var idsToDelete = [gs.mapBackgroundEntityId, gs.mapPlayerEntityId, gs.mapBossEntityId, gs.mapUniqueNpcEntityId];
        var somethingToDelete = false;
        for (var i = 0; i < idsToDelete.length; i++) {
            var id = idsToDelete[i];
            if (typeof id === "number" && id !== -1) {
                var e = doc.queryEntity(id);
                if (e && e.isValid()) {
                    delOp.deleteObject(e);
                    somethingToDelete = true;
                }
            }
        }
        if (somethingToDelete) di.applyOperation(delOp);

        var addOp = new RAddObjectsOperation();
        var newBgEntity, newPlayerEntity, newBossEntity, newUniqueNpcEntity = null;

        var totalHeight = getBaseMapLines().length * Halla.MAP_TEXT_HEIGHT;
        var basePos = new RVector(Halla.MAP_ORIGIN_X, Halla.MAP_ORIGIN_Y + totalHeight);

        var textConstructorArgs = [
            basePos, basePos, Halla.MAP_TEXT_HEIGHT, 0, RS.VAlignTop, RS.HAlignLeft,
            RS.LeftToRight, RS.Exact, 1.0, "", Halla.FONT_NAME, false, false, 0.0, false
        ];

        // Background
        var bgArgs = textConstructorArgs.slice();
        bgArgs[9] = mapData.background;
        var bgData = new RTextData(bgArgs[0], bgArgs[1], bgArgs[2], bgArgs[3], bgArgs[4], bgArgs[5], bgArgs[6], bgArgs[7], bgArgs[8], bgArgs[9], bgArgs[10], bgArgs[11], bgArgs[12], bgArgs[13], bgArgs[14]);
        newBgEntity = new RTextEntity(doc, bgData);
        newBgEntity.setLayerId(bgLayerId);
        newBgEntity.setColor(new RColor(150, 150, 150));
        addOp.addObject(newBgEntity, false);

        // Player
        var playerArgs = textConstructorArgs.slice();
        playerArgs[9] = mapData.player;
        var playerData = new RTextData(playerArgs[0], playerArgs[1], playerArgs[2], playerArgs[3], playerArgs[4], playerArgs[5], playerArgs[6], playerArgs[7], playerArgs[8], playerArgs[9], playerArgs[10], playerArgs[11], playerArgs[12], playerArgs[13], playerArgs[14]);
        newPlayerEntity = new RTextEntity(doc, playerData);
        newPlayerEntity.setLayerId(playerLayerId);
        newPlayerEntity.setColor(new RColor(100, 255, 100));
        addOp.addObject(newPlayerEntity, false);

        // Boss
        if (mapData.bossPos) {
            var bossLines = [];
            var mapLines = getBaseMapLines();
            for (var y = 0; y < mapLines.length; y++) {
                var lineStr = " ".repeat(mapLines[y].length);
                if (y === mapData.bossPos.y) {
                    var lineChars = lineStr.split('');
                    lineChars[mapData.bossPos.x] = mapData.bossChar;
                    lineStr = lineChars.join('');
                }
                bossLines.push(lineStr);
            }
            var bossArgs = textConstructorArgs.slice();
            bossArgs[9] = bossLines.join("\n");
            var bossData = new RTextData(bossArgs[0], bossArgs[1], bossArgs[2], bossArgs[3], bossArgs[4], bossArgs[5], bossArgs[6], bossArgs[7], bossArgs[8], bossArgs[9], bossArgs[10], bossArgs[11], bossArgs[12], bossArgs[13], bossArgs[14]);
            newBossEntity = new RTextEntity(doc, bossData);
            newBossEntity.setLayerId(bossLayerId);
            newBossEntity.setColor(new RColor(255, 50, 50));
            addOp.addObject(newBossEntity, false);
        }

        // Unique NPC
        if (mapData.uniqueNpcPos) {
            var npcLines = [];
            var mapLines = getBaseMapLines();
            for (var y = 0; y < mapLines.length; y++) {
                var lineStr = " ".repeat(mapLines[y].length);
                if (y === mapData.uniqueNpcPos.y) {
                    var lineChars = lineStr.split('');
                    lineChars[mapData.uniqueNpcPos.x] = mapData.uniqueNpcChar;
                    lineStr = lineChars.join('');
                }
                npcLines.push(lineStr);
            }
            var npcArgs = textConstructorArgs.slice();
            npcArgs[9] = npcLines.join("\n");
            var npcData = new RTextData(npcArgs[0], npcArgs[1], npcArgs[2], npcArgs[3], npcArgs[4], npcArgs[5], npcArgs[6], npcArgs[7], npcArgs[8], npcArgs[9], npcArgs[10], npcArgs[11], npcArgs[12], npcArgs[13], npcArgs[14]);
            newUniqueNpcEntity = new RTextEntity(doc, npcData);
            newUniqueNpcEntity.setLayerId(uniqueNpcLayerId);
            newUniqueNpcEntity.setColor(new RColor(100, 150, 255));
            addOp.addObject(newUniqueNpcEntity, false);
        }

        di.applyOperation(addOp);

        gs.mapBackgroundEntityId = newBgEntity.getId();
        gs.mapPlayerEntityId = newPlayerEntity.getId();
        gs.mapBossEntityId = newBossEntity ? newBossEntity.getId() : -1;
        gs.mapUniqueNpcEntityId = newUniqueNpcEntity ? newUniqueNpcEntity.getId() : -1;

        di.regenerateScenes();
        zoomToMap(doc, di);

        return true;
    }

    Halla.generateAsciiMap = generateAsciiMap; Halla.drawAsciiMapToCanvas = drawAsciiMapToCanvas; Halla.ensureLayerAndGetId = ensureLayerAndGetId; Halla.zoomToMap = zoomToMap;

})(this);
