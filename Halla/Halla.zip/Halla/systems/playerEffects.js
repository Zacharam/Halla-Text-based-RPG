// scripts/Halla/Halla/systems/playerEffects.js
// Centrální funkce pro aplikaci efektů na hráče (změna zdraví).

(function (global) {
    "use strict";
    global.Halla = global.Halla || {};
    var Halla = global.Halla;

    /**
     * Bezpečně změní zdraví hráče, aktualizuje UI a zkontroluje smrt.
     * @param {number} amount - Množství, o které se má zdraví změnit. Kladné pro léčení, záporné pro poškození.
     * @param {string} [source=""] - Volitelný zdroj změny pro logování nebo zprávy.
     * @returns {number} Skutečná změna zdraví po aplikaci omezení (0 až maxHealth).
     */
    Halla.changeHealth = function (amount, source) {
        var gs = Halla.gameState;
        if (!gs || amount === 0) return 0;

        var oldHealth = gs.health;
        gs.health += amount;

        // Omezení zdraví v rozsahu 0 až maxHealth
        if (gs.health > gs.maxHealth) gs.health = gs.maxHealth;
        if (gs.health < 0) gs.health = 0;

        var actualChange = gs.health - oldHealth;

        // Aktualizace UI pouze pokud došlo ke skutečné změně
        if (actualChange !== 0 && typeof Halla.updateHealthHearts === "function") {
            Halla.updateHealthHearts();
        }

        // Kontrola smrti
        if (gs.health <= 0) {
            if (typeof Halla.endGameWithSummary === "function") {
                var deathMessage = source ? "Zemřel jsi kvůli: " + source : "Totálně jsi vyhořel.";
                Halla.endGameWithSummary(deathMessage);
            } else {
                gs.running = false;
            }
        }

        return actualChange;
    };

    /**
     * Aplikuje efekty aktuální místnosti (poškození/léčení) na hráče.
     * Tato funkce by se měla volat na začátku každého tahu.
     */
    Halla.applyRoomEffects = function () {
        var gs = Halla.gameState;
        if (!gs) return;

        var room = Halla.rooms[gs.currentRoom];
        if (!room) return;

        var messages = [];
        var totalChange = 0;

        // Získání modifikátorů z třídy hráče
        var playerClass = Halla.getPlayerClass ? Halla.getPlayerClass() : null;
        var healMul = (playerClass && playerClass.healMul) ? playerClass.healMul : 1.0;
        var envDamageMul = (playerClass && playerClass.envDamageMul) ? playerClass.envDamageMul : 1.0;

        // --- LÉČENÍ ---
        if (room.heal && room.heal > 0) {
            // Výpočet náhodného léčení v rozsahu 10-35
            var randomHeal = Math.floor(Math.random() * (35 - 10 + 1)) + 10;
            var healAmount = Math.floor(randomHeal * healMul);
            // Zde by mohly být další modifikátory (perky atd.)
            var actualHeal = Halla.changeHealth(healAmount, "odpočinek v místnosti");
            if (actualHeal > 0) {
                messages.push("Odpočinul sis. +" + actualHeal + " HP.");
                totalChange += actualHeal;
            }
        }

        // --- POŠKOZENÍ ---
        if (room.damage && room.damage > 0) {
            // Výpočet náhodného poškození v rozsahu 1-20
            var randomDamage = Math.floor(Math.random() * (20 - 1 + 1)) + 1;
            var damageAmount = -Math.floor(randomDamage * envDamageMul); // Záporná hodnota pro poškození
            
            // Aplikace perku OVRmind
            if (Halla.hasPerk && Halla.hasPerk("OVRmind")) {
                damageAmount = Math.floor(damageAmount * (Halla.BALANCE.ovrMindDmgMul || 0.7));
            }

            // Aplikace buffu od Ivči
            if (gs.ivcaBuffTurns && gs.ivcaBuffTurns > 0) {
                var originalDamage = damageAmount;
                damageAmount = Math.floor(damageAmount * (Halla.BALANCE.ivcaBuffDmgMul || 0.5));
                gs.ivcaBuffTurns--;
                messages.push("Ivča ti kryje záda! Poškození sníženo z " + (-originalDamage) + " na " + (-damageAmount) + ".");
            }

            var actualDamage = Halla.changeHealth(damageAmount, "prostředí místnosti");
            if (actualDamage < 0) {
                messages.push("Prostředí tě semlelo. " + actualDamage + " HP.");
                totalChange += actualDamage;
            }
        }

        // Zobrazení zprávy, pokud došlo k nějaké změně
        if (totalChange !== 0) {
            var finalMessage = messages.join("\n") + "\n\nNyní máš: " + gs.health + "/" + gs.maxHealth + " HP.";
            Halla.showInfo(finalMessage);
        }
    };

    /**
     * Zpracuje setkání s NPC v aktuální místnosti (např. Ivča).
     */
    Halla.handleNpcEncounters = function () {
        var gs = Halla.gameState;
        if (!gs || !gs.currentRoom) return;

        // Setkání s Ivčou
        if (gs.currentRoom === gs.ivcaRoom) {
            gs.ivcaBuffTurns = Halla.BALANCE.ivcaBuffTurns;
            Halla.showInfo(
                "Potkáváš Ivču.\n" +
                "Chvíli si tě měří a pak si jen povzdechne:\n" +
                "\"Ty to dneska nedáš… tak na pár směn tě podržím.\"\n\n" +
                "Získáváš dočasnou redukci poškození z prostředí."
            );
            if (Halla.journalAddNPC) Halla.journalAddNPC("Ivča", "Roaming NPC, co ti umí na chvíli snížit damage z prostředí.");
        }
    };

    /**
     * Zpracuje setkání s NPC v aktuální místnosti (např. Ivča).
     */
    Halla.handleNpcEncounters = function () {
        var gs = Halla.gameState;
        if (!gs || !gs.currentRoom) return;

        // Setkání s Ivčou
        if (gs.currentRoom === gs.ivcaRoom) {
            gs.ivcaBuffTurns = Halla.BALANCE.ivcaBuffTurns;
            Halla.showInfo(
                "Potkáváš Ivču.\n" +
                "Chvíli si tě měří a pak si jen povzdechne:\n" +
                "\"Ty to dneska nedáš… tak na pár směn tě podržím.\"\n\n" +
                "Získáváš dočasnou redukci poškození z prostředí."
            );
            if (Halla.journalAddNPC) Halla.journalAddNPC("Ivča", "Roaming NPC, co ti umí na chvíli snížit damage z prostředí.");
        }
    };

})(this);