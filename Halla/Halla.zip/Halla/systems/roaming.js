// scripts/Halla/Halla/systems/roaming.js
// Roaming NPC: Ivča (náhodné přemístění mezi definovanými místnostmi).

(function () {
    "use strict";
    // Sjednocení s ostatními soubory: bezpečná reference na Halla namespace
    var Halla = (this.Halla = this.Halla || {});

    Halla.moveIvcaRoaming = function () {
        var gs = Halla.gameState;
        if (!gs) return;

        if (!Halla.IVCA_ROOMS || Halla.IVCA_ROOMS.length === 0) {
            return;
        }

        // pokud ještě nemá pozici, nastav náhodně
        if (!gs.ivcaRoom) {
            // Aktualizováno, aby odpovídalo novému API funkce randomFromArray
            gs.ivcaRoom = Halla.randomFromArray(Halla.IVCA_ROOMS);
            return;
        }

        // Ivča má šanci, že se vůbec nepohne
        if (Math.random() > Halla.BALANCE.ivcaMoveChance) {
            return;
        }

        // kandidáti (všechno kromě aktuální)
        var current = gs.ivcaRoom;
        var candidates = [];
        for (var i = 0; i < Halla.IVCA_ROOMS.length; i++) {
            if (Halla.IVCA_ROOMS[i] !== current) {
                candidates.push(Halla.IVCA_ROOMS[i]);
            }
        }

        if (candidates.length === 0) {
            // Toto by se nemělo stát, pokud je v IVCA_ROOMS více než 1 místnost.
            // Pro jistotu se vrátíme k plnému seznamu.
            candidates = Halla.IVCA_ROOMS;
        }

        // Vyber novou místnost pomocí existující utility
        gs.ivcaRoom = Halla.randomFromArray(candidates);
    };

})();
