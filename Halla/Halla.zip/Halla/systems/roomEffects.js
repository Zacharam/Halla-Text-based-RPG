// scripts/Halla/Halla/systems/roomEffects.js
// Heal / damage podle místnosti (env), včetně perků a Ivča buffu.

(function () {
    // Bezpečná reference na globální jmenný prostor
    var Halla = this.Halla || (this.Halla = {});

    Halla.applyRoomEffects = function () {
        var gs = Halla.gameState;
        if (!gs) return;

        var room = Halla.rooms[gs.currentRoom];
        if (!room) return;

        var BALANCE = Halla.BALANCE;
        var messages = [];
        var healthDelta = 0;
        var oldHealth = gs.health;

        // Získání modifikátorů z hráčovy třídy
        var cls = (typeof Halla.getPlayerClass === "function") ? Halla.getPlayerClass() : null;
        var healMul = (cls && cls.healMul) ? cls.healMul : 1.0;
        var envMul  = (cls && cls.envDamageMul) ? cls.envDamageMul : 1.0;

        // -----------------
        // VÝPOČET LÉČENÍ
        // -----------------
        if (room.heal && room.heal > 0) {
            var baseHeal = Math.floor(room.heal * BALANCE.roomHealBaseMul * healMul);

            // Aplikace perku 'coffeeBoost'
            if (Halla.hasPerk("coffeeBoost")) {
                baseHeal = Math.floor(baseHeal * BALANCE.coffeeBoostHealMul);
            }

            if (baseHeal > 0) {
                healthDelta += baseHeal;
                messages.push("Dal sis kafe. +" + baseHeal + " HP.");
            }
        }

        // Bonus za kouření v kuřárně
        if (gs.currentRoom === "kurarna" &&
            Halla.hasItemInInventory("Krabička cigaret") &&
            Halla.hasItemInInventory("Zapalovač")) {

            var cigHeal = Math.floor(BALANCE.kurarnaHealBase * BALANCE.kurarnaHealMul * healMul);
            if (cigHeal > 0) {
                healthDelta += cigHeal;
                messages.push("Zakouřil jsi si s Kubou a Kubou. +" + cigHeal + " HP.");
                gs.stats.usedKurarnaHeal = true;
                gs.stats.kurarnaHeals = (gs.stats.kurarnaHeals || 0) + 1;
            }
        }


        // -----------------
        // VÝPOČET POŠKOZENÍ
        // -----------------
        if (room.damage && room.damage > 0) {
            var dmg = Math.floor(room.damage * envMul);

            // Aplikace perku 'OVRmind'
            if (Halla.hasPerk("OVRmind")) {
                dmg = Math.floor(dmg * BALANCE.ovrMindDmgMul);
            }

            // Aplikace buffu od Ivči
            if (gs.ivcaBuffTurns && gs.ivcaBuffTurns > 0) {
                var beforeIvca = dmg;
                dmg = Math.floor(dmg * BALANCE.ivcaBuffDmgMul);
                gs.ivcaBuffTurns--;

                messages.push(
                    "Ivča ti kryje záda: environmentální damage snížen z " +
                    beforeIvca + " na " + dmg + " HP. " +
                    "Zbývá " + gs.ivcaBuffTurns + " tahů s ochranou."
                );
            }

            if (dmg > 0) {
                healthDelta -= dmg;
                messages.push("Prostředí tě semlelo. -" + dmg + " HP.");
            }
        }

        // -----------------
        // APLIKACE ZMĚN A VÝSTUP
        // -----------------
        if (healthDelta !== 0 && typeof Halla.changeHealth === "function") {
            // Použijeme centrální funkci, která se postará o vše
            // (omezení, update UI, kontrola smrti).
            Halla.changeHealth(healthDelta, "Prostředí Hally");
            
            // Zobrazíme jen zprávy, protože changeHealth už ukáže finální HP.
            Halla.showInfo(
                messages.join("\n")
            );
        }
    };

})();
