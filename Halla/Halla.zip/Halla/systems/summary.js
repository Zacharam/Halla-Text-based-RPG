// scripts/Halla/Halla/systems/summary.js
// Rekapitulace runu + achievementy + bezpečné ukončení hry.

(function () {
    "use strict";
    // Sjednocení s ostatními soubory: bezpečná reference na Halla namespace
    var Halla = (this.Halla = this.Halla || {});

    // Datově řízený přístup pro achievementy
    var ACHIEVEMENTS_DEFINITIONS = [
        {
            condition: function(gs) { return !(gs.stats || {}).usedKurarnaHeal; },
            text: "Non-smoker – Ani jednou jsi nehealoval v kuřárně."
        },
        {
            condition: function(gs) { return (gs.stats || {}).kurarnaHeals >= 3; },
            text: "Chainsmoker – Kuřárna ti zachránila nervy aspoň 3×."
        },
        {
            condition: function(gs) {
                return Halla.getUltimateItemCount(gs.inventory) === Halla.ULTIMATE_ITEMS.length &&
                       !(Halla.rooms[gs.currentRoom] && Halla.rooms[gs.currentRoom].win);
            },
            text: "All-in worker – Nasbíral jsi všechny ultimátní díly, ale svítidlo jsi ofiko nedotáhl v dílně OVR."
        },
        {
            condition: function(gs) {
                return (gs.endings || {}).pepikVisitCount >= 1 && !(gs.endings || {}).pepikEnding;
            },
            text: "Pepíkův kámoš – Dokázal jsi odejít od Pepíka (alespoň jednou)."
        },
        {
            condition: function(gs) { return (gs.boss || {}).encounters > 0; },
            text: function(gs) { return "Boss enjoyer – Překřížil jsi cestu bossovi " + (gs.boss || {}).encounters + "×."; }
        },
        {
            condition: function(gs) { return (gs.endings || {}).jindraHeroEnding; },
            text: "Jindra HERO – Jindra tě zachránil, když jsi měl většinu ultimátních dílů."
        },
        // --- Nový achievement: Alkoholik ---
        {
            condition: function(gs) { return (gs.stats || {}).rumUsedCount >= 3; },
            text: "Alkoholik – Vypil jsi alespoň 3 lahve rumu v jednom runu."
        },
        // --- Nový achievement: Rumový konec ---
        {
            condition: function(gs) { return (gs.endings || {}).rumEnding === true; },
            text: "Na zdraví! – Rozhodl ses, že už toho bylo dost, a vožral ses na plácku."
        },
        // --- Nové achievementy ---
        {
            condition: function(gs) { return gs.health < 10 && gs.health > 0; },
            text: "Na Káru – Dokončil jsi hru s méně než 10 HP."
        },
        {
            condition: function(gs) { return (gs.stats || {}).turns < 15; },
            text: "Speedrunner – Dokončil jsi hru za méně než 15 tahů."
        },
        {
            // Tento achievement se udělí, pokud byl spuštěn konec s útěkem,
            // ale hra neskončila (hráč se rozhodl zůstat).
            condition: function(gs) { return (gs.endings || {}).choseToStay === true; },
            text: "Pragmatický útěk – Zvažoval jsi útěk, ale nakonec jsi zůstal. S následky."
        },
        // --- Nové achievementy ---
        {
            condition: function(gs) { return Object.keys(gs.journal.rooms).length >= 10; },
            text: "První kroky – Objevil jsi alespoň 10 místností."
        },
        {
            condition: function(gs) { return Halla.getUltimateItemCount(gs.inventory) === Halla.ULTIMATE_ITEMS.length; },
            text: "Sběratel – Sebral jsi všechny Ultimate Itemy."
        },
        {
            condition: function(gs) {
                return (gs.boss || {}).encounters === 0 && gs.running === false;
            },
            text: "Tichý lovec – Dokončil jsi hru, aniž by tě boss dostihl."
        },
        {
            condition: function(gs) {
                return (gs.journal.rooms || {}).tajna_mistnost && gs.journal.rooms.tajna_mistnost.discovered;
            },
            text: "Kancelářský špion – Objevil jsi tajnou místnost."
        },
        // --- Nový achievement: Unikátní setkání ---
        {
            condition: function(gs) {
                return (gs.uniqueNpc && Object.keys(gs.uniqueNpc.encountered).length === Object.keys(Halla.UNIQUE_NPCS).length);
            },
            text: "Sociální motýl – Potkal jsi všechny unikátní postavy v jednom runu."
        }
    ];

    Halla.collectAchievements = function () {
        var gs = Halla.gameState;
        if (!gs) return ["Žádný specifický achievement – prostě další den v práci."];

        var a = [];
        for (var i = 0; i < ACHIEVEMENTS_DEFINITIONS.length; i++) {
            var def = ACHIEVEMENTS_DEFINITIONS[i];
            if (def.condition(gs)) {
                a.push(typeof def.text === 'function' ? def.text(gs) : def.text);
            }
        }

        if (a.length === 0) {
            a.push("Žádný specifický achievement – prostě další den v práci.");
        }

        return a;
    };

    Halla.buildSummaryText = function () {
        var gs = Halla.gameState;
        if (!gs) return "REKAPITULACE: (žádný gameState, gratuluju, rozbil jsi realitu)\n";

        var stats = gs.stats || new Object();
        var endings = gs.endings || new Object();
        var boss = gs.boss || new Object();

        var t = "";
        t += "REKAPITULACE RUNU:\n";
        t += "- Odehraná kola: " + (stats.turns || 0) + "\n";
        t += "- Pohyby (jdi ...): " + (stats.moves || 0) + "\n";
        t += "- Čekání (cekej): " + (stats.waits || 0) + "\n";
        t += "- Naslouchání bossovi: " + (stats.listens || 0) + "\n";
        t += "- Sebrané itemy: " + (stats.itemsPicked || 0) + "\n";
        t += "- Návštěvy Pepíka: " + (endings.pepikVisitCount || 0) + "\n";
        t += "- Setkání s bossem v jedné místnosti: " + (boss.encounters || 0) + "\n";

        var ach = Halla.collectAchievements();
        t += "\nACHIEVEMENTY:\n";
        for (var i = 0; i < ach.length; i++) {
            t += "• " + ach[i] + "\n";
        }

        return t;
    };

    Halla.endGameWithSummary = function (msg) {
        var gs = Halla.gameState;
        if (gs) gs.running = false;

        var summary = Halla.buildSummaryText();

        Halla.showInfo(
            msg + "\n\n--------------------------------\n" + summary
        );
    };

})();
